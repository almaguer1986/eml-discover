# eml-discover

**Stable beta. Patent pending.** Source-available; see LICENSE.

Identify famous mathematical formulas from arbitrary SymPy
expressions. Curated registry of ~17 formulas across statistics, ML
activations, trig/hyperbolic identities, physics, and finance —
each tagged with its Pfaffian-cost class for fast structural
pre-filtering.

## Installation

```bash
pip install eml-discover
```

`eml-cost` is installed as a dependency; `sympy>=1.12` required.

## Quick start

```python
import sympy as sp
from eml_discover import identify

u = sp.Symbol("u")
matches = identify(1 / (1 + sp.exp(-u)))
for m in matches:
    print(m.formula.name, "—", m.confidence)
# sigmoid (canonical) — exact

matches = identify(sp.exp(-u**2 / 2) / sp.sqrt(2 * sp.pi))
print(matches[0].formula.name, matches[0].formula.description)
# Gaussian PDF (standardized) Standard normal probability density.

matches = identify("(log(S/K) + (r + vol**2/2)*T) / (vol*sqrt(T))")
print(matches[0].formula.citation)
# https://en.wikipedia.org/wiki/Black%E2%80%93Scholes_model
```

## How it works

Two-stage match:

1. **Fingerprint pre-filter** (cheap, structural). Every registry
   template carries a [Pfaffian fingerprint](
   https://github.com/almaguer1986/eml-cost) — `p3-d2-w1-c0-h7f3a91`
   etc. Templates whose fingerprint axes don't match the user's
   expression are pruned in O(1) per template.
2. **Symbolic equivalence** (true match). Survivors are checked
   under SymPy variable rename: for each candidate template, try
   permutations of the user's free symbols, accept the rename if
   `sp.simplify(template - user) == 0`.

Returns a list of `Match` ordered by confidence: `identical` (Python
equality, no rename) → `exact` (symbolic equivalence after rename)
→ `axes` (fingerprint axes match but no rename works).

## Registry

Inspect what's registered:

```python
from eml_discover import list_all, list_by_domain, by_name

list_all()                  # every Formula
list_by_domain("physics")   # Bessel J_0, Airy Ai, Boltzmann factor, ...
by_name("Black-Scholes d1") # the d1 Formula
```

Add a formula by appending to `eml_discover.registry.FORMULAS` —
each entry is a small dataclass (`name`, `expression_factory`,
`domain`, `description`, `citation`).

## Use cases

- **"Wait, that's Black-Scholes."** Surface familiar formulas
  hiding in user code or auto-generated symbolic-regression output.
- **Curriculum tools.** Tag a notebook's expressions by their
  registry name → automatic pedagogy ("this cell uses softplus").
- **Patent / claim analysis.** Compare a candidate's formula
  against the public registry of named identities.

## Links

- Project home: [monogate.org](https://monogate.org)
- Source: [github.com/almaguer1986/eml-discover](https://github.com/almaguer1986/eml-discover)
- Companion: [eml-cost](https://github.com/almaguer1986/eml-cost),
  [eml-rewrite](https://github.com/almaguer1986/eml-rewrite)

## License

`PROPRIETARY-PRE-RELEASE`. See LICENSE.
